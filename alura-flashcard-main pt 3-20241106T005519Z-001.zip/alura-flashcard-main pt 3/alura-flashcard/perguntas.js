criaCartao(
    'Cultura POP',
    'Quem é o Homem de Ferro?',
    'Tony Stark é o Homem de Ferro'
)

criaCartao(
    'Biologia',
    'Como a aranha armadeira é conhecida?',
    'Aranha das Bananeiras'
)

criaCartao(
    'Cultura POP',
    'Quem é o Darth Vader?',
    'Anakin Skywalker'
)

criaCartao(
    'Música',
    'Sertanejo raiz usa qual instrumento de cordas?',
    'Viola Caipira'
)

criaCartao(
    'Geografia',
    'O que é uma tromba d´água?',
    'Fenômeno meteorológico que ocorre quando um vórtice de ar gira rapidamente sobre a superfície de um corpo de água'
)

criaCartao(
    'Filmes',
    'Qual esporte Forrest Gump jogou para o exército?',
    'Ping-Pong'
)